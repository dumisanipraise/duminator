package TestNG;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

//package org.openqa.selenium.example;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.testng.annotations.Test;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.BeforeClass;

public class DemoTestNG {
        
	public class SimpleTest {
		 
		public String baseUrl = "https://www.phptravels.net/login";
	    String driverPath = "C:\\Users\\Dumisane.Ndhlovu\\eclipse-workspace\\gecko\\geckodriver.exe";
	    public WebDriver driver ; 
	    
	  @Test//(priority =2 )
	  public void TravelSiteLogin() {
	       
	      System.out.println("Launching Travel website"); 
	      System.setProperty("webdriver.gecko.driver", driverPath);
	      driver = new FirefoxDriver();
	      driver.get(baseUrl);
	      //Wait
	      driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
	     //Find element by ID
	     /* driver.findElement(By.id("username")).sendKeys("demouser");
	      
	      
	      String expectedTitle = "Welcome: Mercury Tours";
	      String actualTitle = driver.getTitle();
	      Assert.assertEquals(actualTitle, expectedTitle);
	      */
	      
	     driver.close();
		 }

	    
	  //Test2
	  @Test//(priority =1 )
	  public void isBritehouseOnline() {
	       
	      System.out.println("launching Britehouse Website"); 
	      System.setProperty("webdriver.gecko.driver", driverPath);
	      driver = new FirefoxDriver();
	      driver.get("https://www.britehouse.co.za");
	     
	      driver.close();
		 }
		}}
