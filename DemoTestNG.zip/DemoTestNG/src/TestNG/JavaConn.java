package TestNG;
import java.io.IOException;
import java.net.MalformedURLException;
import  java.sql.Connection;		
import  java.sql.Statement;		
import  java.sql.ResultSet;		
import  java.sql.DriverManager;		
import  java.sql.SQLException;
import com.gurock.testrail.APIClient;
import com.gurock.testrail.APIException;
import java.util.Map;
import java.util.HashMap;
import org.json.simple.JSONObject;
public class JavaConn {

	public static void main(String[] args) throws  ClassNotFoundException, SQLException, MalformedURLException, IOException, APIException {
		//
		
		APIClient client = new APIClient("https://theduminator.testrail.io/");
		client.setUser("dumisani.praise@gmail.com");
		client.setPassword("lvnUSGCrHoBaZjaOSY7V");
		JSONObject c = (JSONObject) client.sendGet("get_case/1");
		
		System.out.println(c.get("title"));
		
		Map data = new HashMap();
		data.put("status_id", new Integer(1));
		data.put("comment", "This is a test rail integration!");
		JSONObject r = (JSONObject) client.sendPost("add_result_for_case/1/1", data);
		
		
		
		
		// TODO Auto-generated method stub
		
		
		//Connection URL Syntax: "jdbc:mysql://ipaddress:portnumber/db_name"		
        String dbUrl = "jdbc:mysql://localhost:3306/hello";					

		//Database Username		
		String username = "root";	
        
		//Database Password		
		String password = "";				

		//Query to Execute		
		
			
		
		String query = "select *  from destination;";
 	    //Load mysql jdbc driver		
   	    Class.forName("com.mysql.jdbc.Driver");			
   
   		//Create Connection to DB		
    	Connection con = DriverManager.getConnection(dbUrl,username,password);
  
  		//Create Statement Object		
	   Statement stmt = con.createStatement();					
	 //  stmt.executeQuery(query2);
			// Execute the SQL Query. Store results in ResultSet		
 		ResultSet rs= stmt.executeQuery(query);							
 
 		// While Loop to iterate through all data and print results	
 		System. out.println("City ID " +" "+ " City Name");
		while (rs.next()){
	        		String myName = rs.getString(1);								        
                    String mySurname = rs.getString(2);		
                    
                    System. out.println(myName+"  "+mySurname);		
            }		
			 // closing DB Connection		
			con.close();

	}

}
