package TestNG;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

public class Navigator {
	
	
	public static void main(String[] args) {
		
		System.setProperty("webdriver.gecko.driver","C:\\Users\\Dumisane.Ndhlovu\\eclipse-workspace\\gecko\\geckodriver.exe");

		WebDriver driver = new FirefoxDriver();
		
		driver.get("http://newtours.demoaut.com/");
		// TODO Auto-generated method stub

	}

}
